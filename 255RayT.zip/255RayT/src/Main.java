/*
CS-255 Getting started code for the assignment
I do not give you permission to post this code online
Do not post your solution online
Do not copy code
Do not use JavaFX functions or other libraries to do the main parts of the assignment (i.e. ray tracing steps 1-7)
All of those functions must be written by yourself
You may use libraries to achieve a better GUI
*/
import java.io.FileNotFoundException;
import java.util.ArrayList;


import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelWriter;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * @author Caleb Ocansey 2112711 + Jonathan Lee 2033774 as a PAIR
 * **/
public class Main extends Application {
  int Width = 500;
  int Height = 500;

  double r_value, g_value, b_value = 0; //just for the test ex, b_value, b_value = 0;

  double xValue,yValue,zValue;

  public ArrayList<Sphere> worldSpheres = new ArrayList<>();

  public Sphere currentSphere;




  @Override
  public void start(Stage stage) throws FileNotFoundException {
    stage.setTitle("Ray Tracing");

    //We need 3 things to see an image
    //1. We create an image we can write to
    WritableImage image = new WritableImage(Width, Height);
    //2. We create a view of that image
    ImageView view = new ImageView(image);
    //3. Add to the pane (below)

    ToggleGroup toggleGroup = new ToggleGroup();//toggle group for radio buttons

    //3 radio buttons one to select each sphere
    RadioButton radioBtn1 = new RadioButton("Sphere 1");
    radioBtn1.setToggleGroup(toggleGroup);
    radioBtn1.setUserData("1");

    RadioButton radioBtn2 = new RadioButton("Sphere 2");
    radioBtn2.setToggleGroup(toggleGroup);
    radioBtn2.setUserData("2");

    RadioButton radioBtn3 = new RadioButton("Sphere 3");
    radioBtn3.setToggleGroup(toggleGroup);
    radioBtn3.setUserData("3");

    //labels and sliders for sphere x,y,z
    Label xLabel = new Label("X:");
    Slider xSlider = new Slider(-300, 300, xValue);
    xSlider.setShowTickMarks(true);
    xSlider.setShowTickLabels(true);
    xSlider.setMajorTickUnit(50);
    xSlider.setSnapToTicks(true);



    Label yLabel = new Label("Y:");
    Slider ySlider = new Slider(-300, 300, yValue);
    ySlider.setShowTickMarks(true);
    ySlider.setShowTickLabels(true);
    ySlider.setMajorTickUnit(50);


    Label zLabel = new Label("Z:");
    Slider zSlider = new Slider(-200, 300, zValue);
    zSlider.setShowTickMarks(true);
    zSlider.setShowTickLabels(true);
    zSlider.setMajorTickUnit(50);


    // Create an HBox to hold the radio buttons
    HBox radioBox = new HBox(100);
    radioBox.getChildren().addAll(radioBtn1, radioBtn2,radioBtn3);
    radioBox.setAlignment(Pos.BOTTOM_CENTER);

    // Create a VBox to hold the scene contents
    VBox vbox = new VBox(10);
    vbox.setAlignment(Pos.BOTTOM_CENTER);
    vbox.setPadding(new Insets(10));
    vbox.getChildren().addAll(radioBox);

    //labels for r,g,b value sliders for all spheres
    Label rLabel = new Label("Red:");
    Slider rSlider = new Slider(0, 1.0, r_value);
    rSlider.setShowTickMarks(true);
    rSlider.setShowTickLabels(true);
    rSlider.setMajorTickUnit(0.5);


    Label gLabel = new Label("Green:");
    Slider gSlider = new Slider(0, 1.0, g_value);
    gSlider.setShowTickMarks(true);
    gSlider.setShowTickLabels(true);
    gSlider.setMajorTickUnit(0.5);

    Label bLabel = new Label("Blue:");
    Slider bSlider = new Slider(0, 1.0, b_value);
    bSlider.setShowTickMarks(true);
    bSlider.setShowTickLabels(true);
    bSlider.setMajorTickUnit(0.5);

    /* the event listeners for all sliders, which are used to actively update values in the program
    * */
    xSlider.valueProperty().addListener(
            new ChangeListener < Number > () {
              public void changed(ObservableValue < ? extends Number >
                                          observable, Number oldValue, Number newValue) {
                if (currentSphere != null) { //sets the new x of the currently selected sphere if it exists
                  xValue = newValue.doubleValue();
                  currentSphere.getCenter().setX(xValue);
                }
                Render(image); //renders the updated raytracer
              }
            });

    ySlider.valueProperty().addListener(
            new ChangeListener < Number > () {
              public void changed(ObservableValue < ? extends Number >
                                          observable, Number oldValue, Number newValue) {
                if (currentSphere != null) {//sets the new y of the currently selected sphere if it exists
                  yValue = newValue.doubleValue();
                  currentSphere.getCenter().setY(yValue);
                }
                Render(image);//renders the updated raytracer
              }
            });

    zSlider.valueProperty().addListener(
            new ChangeListener < Number > () {
              public void changed(ObservableValue < ? extends Number >
                                          observable, Number oldValue, Number newValue) {
                if (currentSphere != null) { //sets the new z of the currently selected sphere if it exists
                  zValue = newValue.doubleValue();
                  currentSphere.getCenter().setZ(zValue);
                }
                Render(image); //renders the updated raytracer
              }
            });
    //Add all the event handlers
    rSlider.valueProperty().addListener(
      new ChangeListener < Number > () {
        public void changed(ObservableValue < ? extends Number >
          observable, Number oldValue, Number newValue) {
          r_value = newValue.doubleValue(); //gets the updated value from the slider
          for (Sphere s : worldSpheres ) { //changes the red colour value for all the spheres in the raytracer
            s.setR(rSlider.getValue());
          }
          Render(image); //renders the updated raytracer
        }
      });

    //Add all the event handlers
    gSlider.valueProperty().addListener(
            new ChangeListener < Number > () {
              public void changed(ObservableValue < ? extends Number >
                                          observable, Number oldValue, Number newValue) {
                for (Sphere s : worldSpheres ) { //changes the green colour value for all the spheres in the raytracer
                  s.setG(gSlider.getValue());
                }
                Render(image);
              }
            });

    //Add all the event handlers
    bSlider.valueProperty().addListener(
            new ChangeListener < Number > () {
              public void changed(ObservableValue < ? extends Number >
                                          observable, Number oldValue, Number newValue) {
                b_value = newValue.intValue();
                for (Sphere s : worldSpheres ) { //changes the blue colour value for all the spheres in the raytracer
                  s.setB(bSlider.getValue());
                }
                Render(image);
              }
            });

    toggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
      public void changed(ObservableValue<? extends Toggle> ov,
                          Toggle old_toggle, Toggle new_toggle) {
        if (toggleGroup.getSelectedToggle() != null) { /*checks which radio button has been selected then selects
        the corresponding sphere*/
          selectSphere(toggleGroup.getSelectedToggle().getUserData().toString());
          xValue = currentSphere.getCenter().getX(); //sets the x,y,z values of the current sphere
          yValue = currentSphere.getCenter().getY();
          zValue = currentSphere.getCenter().getZ();

          xSlider.setSnapToTicks(true); //snaps the sliders to the current x,y,z values of the current sphere
          xSlider.setValue(xValue);

          ySlider.setSnapToTicks(true);
          ySlider.setValue(yValue);

          zSlider.setSnapToTicks(true);
          zSlider.setValue(zValue);


        }
      }
    });



    GridPane root = new GridPane();
    root.setVgap(12);
    root.setHgap(12);
    //root.setAlignment(Pos.CENTER_LEFT);
    root.getColumnConstraints().add(new ColumnConstraints(80)); // column 0 is 100 wide
    root.getColumnConstraints().add(new ColumnConstraints(400)); // column 1 is 200 wide
    root.getColumnConstraints().add(new ColumnConstraints(400)); // column 1 is 200 wide

    /*adds all the required labels,slides and the rendered image to the window*/
    root.add(view, 0, 0);

    root.add(rLabel,0,1);
    root.add(rSlider, 1, 1);

    root.add(gLabel, 0, 2);
    root.add(gSlider, 1, 2);

    root.add(bLabel,0,3);
    root.add(bSlider,1,3);

    root.add(xLabel,0,4);
    root.add(xSlider,1,4);

    root.add(yLabel,0,5);
    root.add(ySlider,1,5);

    root.add(zLabel,0,6);
    root.add(zSlider,1,6);
    
    root.getChildren().addAll(vbox,radioBox);//adds the radio boxes to the image


    //Display to user
    Scene scene = new Scene(root, 600, 800);
    stage.setScene(scene);
    stage.show();

     //arraylist for all the spheres in the raytraced world
    Sphere sphere1 = new Sphere(new Vector(-110,200,0),100,1,1,1);//centre of sphere)
    Sphere sphere2 = new Sphere(new Vector(200, 100, 100), 50,0.8,0.5,0.2);
    Sphere sphere3 = new Sphere(new Vector(-300, 150, 30), 100,1,0.5,0);
    worldSpheres.add(sphere1);
    worldSpheres.add(sphere2);
    worldSpheres.add(sphere3);
  }

  public void Render(WritableImage image) {
    //Get image dimensions, and declare loop variables
    int w = (int) image.getWidth(), h = (int) image.getHeight(), i, j;
    PixelWriter image_writer = image.getPixelWriter();

    Vector origin= new Vector(0,0,0); //origin of ray
    Vector Light = new Vector(100,100,-200);

    for (j = 0; j < h; j++) {
      for (i = 0; i < w; i++) {
        origin.x = i -250;
        origin.y = j -250;
        origin.z =-200;

        double u = (2.0 * i - w) / w; //scales the pixels
        double v = (2.0 * j - h) / h;
        Vector dir = new Vector(u, v, 1);
        dir.normalise();

        Color color = TraceRay(origin, dir, worldSpheres, Light); //used to trace the colours


        image_writer.setColor(i, j, color);
      } // column loop
    } // row loop
  }
  private Color TraceRay(Vector origin, Vector direction, ArrayList<Sphere> spheres, Vector light) {
      // Find the closest intersection with the scene
      double closest_t = Double.MAX_VALUE;
      Sphere closest_sphere = null;
      double t;
    for (Sphere sphere : spheres) {
      t = sphere.intersect(origin, direction);

      if (t > 0.0 && t < closest_t) {
        closest_t = t;
        closest_sphere = sphere;
      }
    }

        if (closest_sphere != null) {
          // Compute the intersection point and surface normal
          Vector p = origin.add(direction.mul(closest_t));
          Vector n = p.sub(closest_sphere.getCenter());
          n.normalise();

          // Compute the diffuse shading
          light.normalise();
          double diffuse = Math.max(0, n.dot(light));
          double diffuseR = closest_sphere.getR() * diffuse;
          double diffuseG = closest_sphere.getG() * diffuse;
          double diffuseB = closest_sphere.getB() * diffuse;

          // Return the final color
          return new Color(diffuseR, diffuseG, diffuseB, 1);

        } else {  // If there is no intersection, return background color
          return Color.BLACK;
        }

      }

      public void selectSphere(String sphereName){ //used to select the current sphere
    if (sphereName.equals("1")){
      currentSphere = worldSpheres.get(0);
        } else if (sphereName.equals("2")){
      currentSphere = worldSpheres.get(1);
    } else {
      currentSphere = worldSpheres.get(2);
    }
      }


    public static void main(String[] args) {
    launch();
  }

}