import javafx.scene.paint.Color;

public class Sphere {

    private Vector center;  // the position of the center of the sphere
    private double radius;  // the radius of the sphere
    private double r,g,b; //rgb decimals used to create colour
    private String sphereName;

    public static int numOfSpheres;
    public Sphere(Vector center, double radius, double r,double g ,double b) {
        this.center = center;
        this.radius = radius;
        this.r = r;
        this.g = g;
        this.b = b;
        numOfSpheres++;
        this.sphereName ="Sphere "+ numOfSpheres;
    }

    public Vector getCenter() {
        return center;
    }


    public Color getColour(){
        return Color.color(this.r,this.g,this.b);
    }

    public double getR(){
        return this.r;
    }

    public double getG(){
        return this.g;
    }

    public double getB(){
        return this.b;
    }

    public void setR( double r){
        this.r= r;
    }

    public void setG( double g){
        this.g= g;
    }

    public void setB( double b){
        this.b= b;
    }

    // Check if a given ray intersects with this sphere, and return the distance
    // to the point of intersection, or -1 if there is no intersection.
    public double intersect(Vector origin, Vector direction) {
        // Use the sphere intersection test we discussed earlier
        Vector v = origin.sub(center);
        double a = direction.dot(direction);
        double b = 2.0 * v.dot(direction);
        double c = v.dot(v) - radius * radius;

        double discriminant = Math.pow(b, 2) - 4 * a * c;

        // Compute the two intersection points
        double t1 = (-b - Math.sqrt(discriminant)) / (2 * a);
        double t2 = (-b + Math.sqrt(discriminant)) / (2 * a);

        // Return the closest intersection point that is in front of the camera
        if (t1 >= 0 && t2 >= 0) {
            return Math.min(t1, t2);
        } else if (t1 >= 0) {
            return t1;
        } else if (t2 >= 0) {
            return t2;
        } else {
            return -1.0;
        }

    }

    public String getSphereName() {
        return sphereName;
    }
}